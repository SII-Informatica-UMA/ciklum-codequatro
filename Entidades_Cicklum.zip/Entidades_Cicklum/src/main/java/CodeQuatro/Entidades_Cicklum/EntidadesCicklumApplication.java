package CodeQuatro.Entidades_Cicklum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EntidadesCicklumApplication {

	public static void main(String[] args) {
		SpringApplication.run(EntidadesCicklumApplication.class, args);
	}

}
