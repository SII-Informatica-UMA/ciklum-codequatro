package CodeQuatro.Entidades_Cicklum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntidadesCicklumApplicationTests {

	@Test
	void contextLoads() {
	}

}
